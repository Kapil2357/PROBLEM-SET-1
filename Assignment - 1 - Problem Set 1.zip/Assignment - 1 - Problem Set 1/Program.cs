﻿//Question 4

//int[] arr_ = new int[5];
//int[] arr_1 = new int[5];
//int[] arr_2 = new int[5];
//Console.WriteLine("Question 4 - Read and print 5 even and odd numbers"); for (int i = 0; i < 5; i++) //Read the numbers and store in array
//{
//    Console.WriteLine("\nEnter a number: ");
//    arr_[i] = Convert.ToInt32(Console.ReadLine());
//}
//for (int j = 0; j < 5; j++)
//{
//    Console.WriteLine("\nElement - {0}: {1}", j, arr_[j]);
//}
//int remainder = 0; //Save the odd and even numbers in array
//int remainder2 = 0;
//for (int k = 0; k < 5; k++)
//{
//    double x = arr_[k] % 2;
//    if (x == 0)
//    {
//        arr_1[remainder] = arr_[k];
//        remainder++;
//    }
//    else
//    {
//        arr_2[remainder2] = arr_[k];
//        remainder2++;
//    }
//}
////Print the output arrays
//Console.WriteLine("\nThe even numbers are: ");
//for (int l = 0; l < arr_1.Length; l++)
//{
//    if (arr_1[l] != 0)
//        Console.Write("{0} ", arr_1[l]);
//}
//Console.WriteLine("\nThe odd numbers are: ");
//for (int m = 0; m < arr_2.Length; m++)
//{
//    if (arr_2[m] != 0)
//        Console.Write("{0} ", arr_2[m]);
//}

//Question 2

//Console.Write("Input string: 'Supercalifragilisticexpialidocious' ");
//string InputStr1 = "Supercalifragilisticexpialidocious";  //read string
//Console.WriteLine("\na. Total characters in string {0} : {1}", InputStr1, InputStr1.Length);
//bool check;
//if (check = InputStr1.Contains("ice") == true)
//{
//    Console.WriteLine("\nb. The string does contain 'ice' : {0}", check);
//}
//string InputStr2 = "Honorificabilitudinitatibus";
//string InputStr3 = "Bababadalgharaghtakamminarronnkonn";
//if (InputStr1.Length > InputStr2.Length)
//{
//    if (InputStr1.Length > InputStr3.Length)
//    {
//        Console.WriteLine("\nc. The Longes String is: {0}", InputStr1);
//    }
//    else
//    {
//        Console.WriteLine("\nc. The Longes String is: {0}", InputStr3);
//    }
//}
//else
//{
//    if (InputStr2.Length > InputStr3.Length)
//    {
//        Console.WriteLine("\nc. The Longes String is: {0}", InputStr2);
//    }
//    else
//    {
//        Console.WriteLine("\nc. The Longes String is: {0}", InputStr3);
//    }
//}
//Console.WriteLine("\nd.Which composer comes first in the dictonary?");
//List<string> list1 = new List<string>(7); list1.Add("Berlioz");
//list1.Add("Borodin");
//list1.Add("Brian");
//list1.Add("Bartok");
//list1.Add("Bellini");
//list1.Add("Buxtehude");
//list1.Add("Bernstein"); list1.Sort();
//Console.WriteLine("\nAlphabetically, the first name of the list is : {0}", list1[0]);
//Console.WriteLine("\nAlphabetically, the first name of the list is : {0}", list1[6]);

//Question 3
double area;
double x;
double a1;
double b1;
double c1;
Console.WriteLine("\n3. Calculator for triangule area");
Console.WriteLine("\nEnter the first side: ");
string a = Console.ReadLine();
a1 = Convert.ToDouble(a);
Console.WriteLine("\nEnter the second side: ");
string b = Console.ReadLine();
b1 = Convert.ToDouble(b);
Console.WriteLine("\nEnter the third side: ");
string c = Console.ReadLine();
c1 = Convert.ToDouble(c);
x = (a1 + b1 + c1) * 0.5;
Console.WriteLine("\nValue of s: {0}", x);
area = (x * (x - a1) * (x - b1) * (x - c1));
Console.WriteLine("\nValue of area: {0}", Math.Sqrt(area));